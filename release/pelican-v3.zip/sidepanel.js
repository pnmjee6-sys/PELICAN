// src/core/storage.ts
var DEFAULT_BACKEND_URL = true ? "https://context-passport-api-3dvk.onrender.com" : "http://127.0.0.1:8000";
var DEFAULT_SETTINGS = {
  // Capture is OFF by default across all sites
  capture_chatgpt: false,
  capture_claude: false,
  capture_gemini: false,
  backend_url: DEFAULT_BACKEND_URL,
  auth_token: "",
  refresh_token: "",
  user_email: ""
};
var memoryStore = { ...DEFAULT_SETTINGS };
function packagedBackendUrl() {
  const url = typeof chrome !== "undefined" && chrome.runtime?.getManifest?.().homepage_url;
  return typeof url === "string" && /^https:\/\//.test(url) ? url.replace(/\/+$/, "") : DEFAULT_BACKEND_URL;
}
function hasChromeStorage() {
  return typeof chrome !== "undefined" && !!chrome.storage && !!chrome.storage.local;
}
async function getSetting(key) {
  if (hasChromeStorage()) {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (result) => {
        if (result && result[key] !== void 0) {
          resolve(result[key]);
        } else {
          resolve(key === "backend_url" ? packagedBackendUrl() : DEFAULT_SETTINGS[key]);
        }
      });
    });
  }
  return memoryStore[key] !== void 0 ? memoryStore[key] : DEFAULT_SETTINGS[key];
}
async function setSetting(key, value) {
  memoryStore[key] = value;
  if (hasChromeStorage()) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [key]: value }, () => resolve());
    });
  }
}
async function getAllSettings() {
  if (hasChromeStorage()) {
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (result) => {
        resolve({
          ...DEFAULT_SETTINGS,
          backend_url: packagedBackendUrl(),
          ...result
        });
      });
    });
  }
  return { ...DEFAULT_SETTINGS, ...memoryStore };
}
async function isSiteCaptureEnabled(site) {
  const key = `capture_${site}`;
  const val = await getSetting(key);
  return Boolean(val);
}
async function setSiteCaptureEnabled(site, enabled) {
  const key = `capture_${site}`;
  await setSetting(key, enabled);
}

// src/core/api.ts
var AuthRequiredError = class extends Error {
  constructor() {
    super("Session expired. Sign in again.");
    this.name = "AuthRequiredError";
  }
};
var pendingRefreshes = /* @__PURE__ */ new Map();
var ContextPassportApiClient = class {
  backendUrl;
  token;
  constructor(backendUrl = DEFAULT_BACKEND_URL, token = "") {
    this.backendUrl = backendUrl.replace(/\/+$/, "");
    this.token = token.trim().replace(/^Bearer\s+/i, "");
  }
  setToken(token) {
    this.token = token.trim().replace(/^Bearer\s+/i, "");
  }
  setBackendUrl(url) {
    this.backendUrl = url.replace(/\/+$/, "");
  }
  getHeaders() {
    const headers = {
      "Content-Type": "application/json"
    };
    if (this.token) {
      headers["Authorization"] = `Bearer ${this.token}`;
    }
    return headers;
  }
  async request(path, init = {}) {
    const send = () => fetch(`${this.backendUrl}${path}`, {
      ...init,
      headers: { ...init.headers, ...this.getHeaders() }
    });
    let response = await send();
    if (response.status !== 401) return response;
    const refresh = await getSetting("refresh_token");
    if (!refresh) {
      await this.clearSession();
      throw new AuthRequiredError();
    }
    const key = `${this.backendUrl}:${refresh}`;
    let pending = pendingRefreshes.get(key);
    if (!pending) {
      pending = this.refreshToken(refresh).finally(() => pendingRefreshes.delete(key));
      pendingRefreshes.set(key, pending);
    }
    try {
      this.token = await pending;
      response = await send();
    } catch {
      if (await getSetting("refresh_token") === refresh) await this.clearSession();
      throw new AuthRequiredError();
    }
    if (response.status === 401) {
      await this.clearSession();
      throw new AuthRequiredError();
    }
    return response;
  }
  async clearSession() {
    this.token = "";
    await Promise.all([
      setSetting("auth_token", ""),
      setSetting("refresh_token", ""),
      setSetting("user_email", "")
    ]);
  }
  async logout() {
    const refresh = await getSetting("refresh_token");
    const access = this.token;
    await this.clearSession();
    if (refresh) {
      void fetch(`${this.backendUrl}/api/v1/auth/logout`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: AbortSignal.timeout(2500),
        body: JSON.stringify({ refresh_token: refresh, access_token: access })
      }).catch(() => {
      });
    }
  }
  async checkHealth() {
    try {
      const res = await fetch(`${this.backendUrl}/health`);
      if (!res.ok) return { ok: false, status: `HTTP ${res.status}` };
      const data = await res.json();
      return { ok: true, status: data.status, version: data.version };
    } catch (err) {
      return { ok: false, status: err.message || "Offline" };
    }
  }
  async checkReady() {
    try {
      const res = await fetch(`${this.backendUrl}/ready`);
      const data = await res.json();
      return { ready: data.status === "ready", missing: data.missing };
    } catch {
      return { ready: false, missing: ["Server Unreachable"] };
    }
  }
  async login(email, password) {
    const res = await fetch(`${this.backendUrl}/api/v1/auth/token`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: "Authentication failed" }));
      throw new Error(err.detail || "Authentication failed");
    }
    const data = await res.json();
    if (!data.access_token) throw new Error("Authentication did not return a session");
    this.token = data.access_token;
    await setSetting("auth_token", data.access_token);
    await setSetting("refresh_token", data.refresh_token || "");
    return data.access_token;
  }
  async refreshToken(refreshToken) {
    const res = await fetch(`${this.backendUrl}/api/v1/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: refreshToken })
    });
    if (!res.ok) {
      throw new Error("Failed to refresh token");
    }
    const data = await res.json();
    if (!data.access_token || !data.refresh_token) throw new Error("Invalid refresh response");
    this.token = data.access_token;
    await setSetting("auth_token", data.access_token);
    await setSetting("refresh_token", data.refresh_token);
    return data.access_token;
  }
  async ingestMessage(payload) {
    const res = await this.request("/api/v1/messages/ingest", {
      method: "POST",
      headers: this.getHeaders(),
      body: JSON.stringify({
        conversation_id: payload.conversation_id,
        text: payload.text,
        role: payload.role || "user",
        is_extension_context: Boolean(payload.is_extension_context),
        event_id: payload.event_id,
        source_site: payload.source_site
      })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Ingest failed with status ${res.status}`);
    }
    return res.json();
  }
  async queryMemories(query, maxGeneral = 3) {
    const res = await this.request("/api/v1/memories/query", {
      method: "POST",
      headers: this.getHeaders(),
      body: JSON.stringify({
        query,
        max_general: maxGeneral
      })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Memory query failed with status ${res.status}`);
    }
    return res.json();
  }
  async getAllMemories() {
    const res = await this.request("/api/v1/memories", {
      method: "GET",
      headers: this.getHeaders()
    });
    if (!res.ok) {
      throw new Error(`Failed to load memories: HTTP ${res.status}`);
    }
    return res.json();
  }
  async blockMemory(memoryId) {
    const res = await this.request(`/api/v1/memories/${encodeURIComponent(memoryId)}/block`, {
      method: "POST",
      headers: this.getHeaders()
    });
    return res.ok;
  }
  async updateMemory(memoryId, text) {
    const res = await this.request(`/api/v1/memories/${encodeURIComponent(memoryId)}`, {
      method: "PUT",
      headers: this.getHeaders(),
      body: JSON.stringify({ text })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      throw new Error(err.detail || `Memory update failed: HTTP ${res.status}`);
    }
    return res.json();
  }
  async deleteMemory(memoryId) {
    const res = await this.request(`/api/v1/memories/${encodeURIComponent(memoryId)}`, {
      method: "DELETE",
      headers: this.getHeaders()
    });
    return res.ok;
  }
  async getPreferences() {
    const res = await this.request("/api/v1/preferences", {
      method: "GET",
      headers: this.getHeaders()
    });
    if (!res.ok) {
      throw new Error(`Failed to load preferences: HTTP ${res.status}`);
    }
    return res.json();
  }
  async updatePreference(preferenceId, newText) {
    const res = await this.request(`/api/v1/preferences/${encodeURIComponent(preferenceId)}`, {
      method: "PUT",
      headers: this.getHeaders(),
      body: JSON.stringify({ preference_text: newText })
    });
    if (!res.ok) {
      throw new Error(`Failed to update preference: HTTP ${res.status}`);
    }
    return res.json();
  }
  async removePreferenceEvidence(preferenceId, observationId) {
    const res = await this.request(`/api/v1/preferences/${encodeURIComponent(preferenceId)}/observations/${encodeURIComponent(observationId)}`, {
      method: "DELETE",
      headers: this.getHeaders()
    });
    if (!res.ok) throw new Error(`Could not remove evidence: HTTP ${res.status}`);
    return (await res.json()).ok === true;
  }
  async blockPreference(preferenceId) {
    const res = await this.request(`/api/v1/preferences/${encodeURIComponent(preferenceId)}/block`, {
      method: "POST",
      headers: this.getHeaders()
    });
    if (!res.ok) throw new Error(`Could not block preference: HTTP ${res.status}`);
    return (await res.json()).ok === true;
  }
  async forgetPreference(preferenceId) {
    const res = await this.request(`/api/v1/preferences/${encodeURIComponent(preferenceId)}`, {
      method: "DELETE",
      headers: this.getHeaders()
    });
    if (!res.ok) throw new Error(`Could not forget preference: HTTP ${res.status}`);
    return (await res.json()).ok === true;
  }
};

// src/core/injection.ts
var INJECTION_START_MARKER = "[Context Passport: Memory]";
var INJECTION_END_MARKER = "[/Context Passport]";
var INJECTION_BLOCK_REGEX = /\[Context Passport:[^\]]*\][\s\S]*?\[\/Context Passport\]/gi;
var COMMENT_BLOCK_REGEX = /<!--\s*CONTEXT_PASSPORT_START[\s\S]*?CONTEXT_PASSPORT_END\s*-->/gi;
var FALLBACK_BLOCK_REGEX = /<!-- Context-Passport[\s\S]*?-->/gi;
function stripExtensionInjectedContext(text) {
  if (!text) return "";
  let cleaned = text.replace(INJECTION_BLOCK_REGEX, "");
  cleaned = cleaned.replace(COMMENT_BLOCK_REGEX, "");
  cleaned = cleaned.replace(FALLBACK_BLOCK_REGEX, "");
  return cleaned.trim();
}
function formatMemoryBlock(generalMemories = [], sensitiveMemories = [], preferences = []) {
  const parts = [];
  const allMemories = [...generalMemories, ...sensitiveMemories];
  if (allMemories.length > 0) {
    parts.push("Relevant Memories:");
    for (const mem of allMemories) {
      const clean = mem.text.trim();
      if (clean) {
        parts.push(`- ${clean}`);
      }
    }
  }
  if (preferences.length > 0) {
    if (parts.length > 0) parts.push("");
    parts.push("User Response Preference:");
    for (const pref of preferences) {
      const clean = pref.preference_text.trim();
      if (clean) {
        parts.push(`- ${clean}`);
      }
    }
  }
  if (parts.length === 0) {
    return "";
  }
  return `${INJECTION_START_MARKER}
${parts.join("\n")}
${INJECTION_END_MARKER}

`;
}
function applyMemoryBlockToDraft(currentDraft, newBlock) {
  const cleanDraftWithoutOldBlock = stripExtensionInjectedContext(currentDraft);
  if (!newBlock || newBlock.trim() === "") {
    return cleanDraftWithoutOldBlock;
  }
  if (cleanDraftWithoutOldBlock.length > 0) {
    return `${newBlock.trim()}

${cleanDraftWithoutOldBlock}`;
  }
  return newBlock.trim();
}

// src/core/screener.ts
var SECRET_PATTERNS = [
  { name: "Private Key", pattern: /-----BEGIN[ A-Z0-9_-]*PRIVATE KEY-----/ },
  { name: "Google API Key", pattern: /AIza[0-9A-Za-z-_]{35}/ },
  { name: "OpenAI API Key", pattern: /sk-[a-zA-Z0-9_-]{20,}/ },
  { name: "Anthropic API Key", pattern: /sk-ant-[a-zA-Z0-9_-]{20,}/ },
  { name: "Supabase Secret Token", pattern: /sbp_[a-zA-Z0-9]{20,}/ },
  { name: "GitHub Token", pattern: /(?:gh[pousr]_[A-Za-z0-9_]{36,}|github_pat_[0-9a-zA-Z_]{82})/ },
  { name: "AWS Access Key", pattern: /AKIA[0-9A-Z]{16}/ },
  // Generic API key assignments: e.g. api_key=xyz, api-key: "xyz", access_token: xyz (quoted or unquoted)
  {
    name: "Generic API Key Assignment",
    pattern: /(?:\bapi[_-]?key|\bsecret[_-]?key|\baccess[_-]?token|\bauth[_-]?token)\s*[:=]\s*['"]?([a-zA-Z0-9_\-\.]{12,})['"]?/i
  },
  // Generic password assignments: e.g. password: xyz, password is xyz, passwd=xyz, pwd: 'xyz' (quoted or unquoted)
  {
    name: "Generic Password Assignment",
    pattern: /(?:\bpassword|\bpasswd|\bpwd)\s*(?:[:=]|\bis\b)\s*['"]?([^\s'"]{6,})['"]?/i
  },
  // Bearer Token
  { name: "Bearer Token Assignment", pattern: /\bBearer\s+([a-zA-Z0-9_\-\.]{12,})/i },
  // Financial numbers
  { name: "Credit Card Number", pattern: /\b(?:\d{4}[ -]?){3}\d{4}\b/ },
  { name: "Social Security Number", pattern: /\b\d{3}-\d{2}-\d{4}\b/ }
];
var SENSITIVE_PATTERNS = [
  {
    name: "Allergy and Health Sensitivity",
    pattern: /\b(allergy|allergies|allergic|epipen|anaphylaxis|gluten allergy|dairy allergy|nut allergy|shellfish allergy)\b/i
  },
  {
    name: "Medical Condition",
    pattern: /\b(medical condition|diagnosis|diagnosed with|prescription|medication|doctor's note|health record|bipolar|depression|cancer|hiv|pregnancy|addiction|diabetes|hospitalized)\b/i
  },
  {
    name: "Financial and Confidential",
    pattern: /\b(salary|income|bank account|routing number|credit score|passport number|social security|confidential project|strictly confidential|under nda|proprietary|tax return)\b/i
  },
  {
    name: "Identity and Contact Info",
    pattern: /\b(government id|national id|aadhaar|pan number|driver'?s license number|home address|street address|mailing address|phone number|mobile number|personal email|religion|religious belief|sexual orientation|gender identity|political affiliation|date of birth|birthday|legal name)\b/i
  },
  { name: "Email Address", pattern: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i },
  { name: "Personal Address", pattern: /\b(?:my|our|home|live at|reside at)\b.{0,30}\b\d{1,6}\s+[A-Za-z0-9 .'-]{2,50}\b(?:street|st\.?|road|rd\.?|avenue|ave\.?|lane|ln\.?|drive|dr\.?|boulevard|blvd\.?)\b/i },
  { name: "Phone Number", pattern: /\b(?:my|call me at|reach me at|phone(?: number)? is)\b.{0,25}(?:\+?\d[\d .()\-]{8,}\d)\b/i },
  { name: "Religious Identity", pattern: /\b(?:i am|i'm|my faith is)\s+(?:a\s+)?(?:buddhist|christian|muslim|hindu|jewish|sikh|atheist)\b/i },
  {
    name: "Uncertain / Speculative Fact",
    pattern: /\b(uncertain|not sure if|unconfirmed|tentative|provisional|speculative)\b/i
  }
];
function containsSecret(text) {
  if (!text) return false;
  return SECRET_PATTERNS.some((p) => p.pattern.test(text));
}
function containsSensitive(text) {
  if (!text) return false;
  return SENSITIVE_PATTERNS.some((p) => p.pattern.test(text));
}

// src/core/recall.ts
function screenRecall(response) {
  const general = [];
  const sensitive = [];
  for (const memory of [...response.general_memories || [], ...response.sensitive_memories || []]) {
    if (!memory.text || memory.classification === "secret" || containsSecret(memory.text)) continue;
    if (memory.classification === "sensitive" || (response.sensitive_memories || []).includes(memory) || containsSensitive(memory.text)) {
      sensitive.push(memory);
    } else {
      general.push(memory);
    }
  }
  const preferences = (response.preferences || []).filter((pref) => Boolean(pref.preference_text) && !containsSecret(pref.preference_text) && !containsSensitive(pref.preference_text));
  return { general: general.slice(0, 3), sensitive, preferences };
}

// src/sidepanel/index.ts
var apiClient;
async function syncAccountView() {
  const token = await getSetting("auth_token");
  const email = await getSetting("user_email");
  const signedIn = document.getElementById("cp-signed-in");
  const signIn = document.getElementById("cp-sign-in-form");
  if (signedIn) signedIn.hidden = !token;
  if (signIn) signIn.hidden = Boolean(token);
  const label = document.getElementById("cp-account-email");
  if (label) label.textContent = email || "Your account";
}
async function ensureBackendPermission(rawUrl) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error("Enter a valid backend URL.");
  }
  if (url.pathname !== "/" || url.search || url.hash) throw new Error("Enter the backend origin without a path or query.");
  const local = url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname) && url.port === "8000";
  if (!local && url.protocol !== "https:") throw new Error("Use HTTPS for a hosted backend.");
  if (local) return;
  const origins = [`${url.origin}/*`];
  if (!await chrome.permissions.request({ origins })) {
    throw new Error("Allow access to this backend to continue.");
  }
}
document.addEventListener("DOMContentLoaded", async () => {
  const settings = await getAllSettings();
  apiClient = new ContextPassportApiClient(settings.backend_url, settings.auth_token);
  initTabs();
  initSettings(settings);
  initConnectionStatus();
  initVault();
  initPreferences();
  initFallback();
  await syncAccountView();
  if (!settings.auth_token) switchToTab("settings");
  chrome.storage?.onChanged?.addListener((changes, area) => {
    if (area !== "local" || !changes.auth_token) return;
    apiClient.setToken(changes.auth_token.newValue || "");
    void syncAccountView();
    if (!changes.auth_token.newValue) {
      void loadVaultMemories();
      void loadPreferences();
    }
  });
  document.getElementById("open-dashboard-btn")?.addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
  });
  document.getElementById("open-onboarding-btn")?.addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
  });
});
function switchToTab(target) {
  const tabBtns = document.querySelectorAll(".cp-nav-btn");
  const tabPanes = document.querySelectorAll(".cp-tab-pane");
  tabBtns.forEach((btn) => {
    const isTarget = btn.getAttribute("data-tab") === target;
    btn.classList.toggle("active", isTarget);
    btn.setAttribute("aria-selected", isTarget ? "true" : "false");
  });
  tabPanes.forEach((pane) => {
    pane.classList.toggle("active", pane.id === `tab-${target}`);
  });
  if (target === "vault") loadVaultMemories();
  if (target === "preferences") loadPreferences();
}
function initTabs() {
  const tabBtns = document.querySelectorAll(".cp-nav-btn");
  tabBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.getAttribute("data-tab");
      if (target) switchToTab(target);
    });
    btn.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        const target = btn.getAttribute("data-tab");
        if (target) switchToTab(target);
      }
    });
  });
}
async function initConnectionStatus() {
  const badge = document.getElementById("connection-badge");
  if (!badge) return;
  const health = await apiClient.checkHealth();
  if (!health.ok) {
    badge.textContent = "Offline";
    badge.className = "cp-badge cp-badge-error";
    return;
  }
  const ready = await apiClient.checkReady();
  if (!ready.ready) {
    badge.textContent = "Backend not ready";
    badge.className = "cp-badge cp-badge-error";
    return;
  }
  if (!await getSetting("auth_token")) {
    badge.textContent = "Sign in";
    badge.className = "cp-badge cp-badge-neutral";
    return;
  }
  try {
    await apiClient.getPreferences();
    badge.textContent = "Connected";
    badge.className = "cp-badge cp-badge-success";
  } catch (err) {
    badge.textContent = /HTTP 401|HTTP 403|token_expired|Session expired/i.test(err?.message || "") ? "Sign in again" : "Backend error";
    badge.className = "cp-badge cp-badge-error";
  }
}
async function initSettings(settings) {
  const toggleChatGPT = document.getElementById("toggle-chatgpt");
  const toggleClaude = document.getElementById("toggle-claude");
  const toggleGemini = document.getElementById("toggle-gemini");
  const urlInput = document.getElementById("setting-backend-url");
  const tokenInput = document.getElementById("setting-auth-token");
  const emailInput = document.getElementById("setting-email");
  const passwordInput = document.getElementById("setting-password");
  const signInBtn = document.getElementById("sign-in-btn");
  const signOutBtn = document.getElementById("sign-out-btn");
  const authMessage = document.getElementById("auth-message");
  const saveBtn = document.getElementById("save-settings-btn");
  if (toggleChatGPT) {
    toggleChatGPT.checked = await isSiteCaptureEnabled("chatgpt");
    toggleChatGPT.addEventListener("change", async () => {
      await setSiteCaptureEnabled("chatgpt", toggleChatGPT.checked);
    });
  }
  if (toggleClaude) {
    toggleClaude.checked = await isSiteCaptureEnabled("claude");
    toggleClaude.addEventListener("change", async () => {
      await setSiteCaptureEnabled("claude", toggleClaude.checked);
    });
  }
  if (toggleGemini) {
    toggleGemini.checked = await isSiteCaptureEnabled("gemini");
    toggleGemini.addEventListener("change", async () => {
      await setSiteCaptureEnabled("gemini", toggleGemini.checked);
    });
  }
  if (urlInput) urlInput.value = settings.backend_url || DEFAULT_BACKEND_URL;
  if (tokenInput) tokenInput.value = settings.auth_token || "";
  if (emailInput) emailInput.value = settings.user_email || "";
  signInBtn?.addEventListener("click", async () => {
    const email = emailInput?.value.trim() || "";
    const password = passwordInput?.value || "";
    if (!email || !password) {
      if (authMessage) {
        authMessage.textContent = "Enter your email and password.";
        authMessage.className = "cp-hint-text cp-hint-error";
      }
      return;
    }
    signInBtn.disabled = true;
    try {
      const backendUrl = urlInput?.value.trim() || DEFAULT_BACKEND_URL;
      await ensureBackendPermission(backendUrl);
      apiClient.setBackendUrl(backendUrl);
      const token = await apiClient.login(email, password);
      await setSetting("backend_url", backendUrl);
      await setSetting("auth_token", token);
      await setSetting("user_email", email);
      await syncAccountView();
      if (tokenInput) tokenInput.value = token;
      if (authMessage) {
        authMessage.textContent = "Signed in successfully. Your password was not saved.";
        authMessage.className = "cp-hint-text cp-hint-success";
      }
      await initConnectionStatus();
      await loadVaultMemories();
      await loadPreferences();
    } catch (err) {
      if (authMessage) {
        authMessage.textContent = `Sign-in failed: ${err.message || "Try again."}`;
        authMessage.className = "cp-hint-text cp-hint-error";
      }
    } finally {
      if (passwordInput) passwordInput.value = "";
      signInBtn.disabled = false;
    }
  });
  signOutBtn?.addEventListener("click", async () => {
    await apiClient.logout();
    await syncAccountView();
    if (tokenInput) tokenInput.value = "";
    if (passwordInput) passwordInput.value = "";
    if (emailInput) emailInput.value = "";
    if (authMessage) {
      authMessage.textContent = "Signed out successfully.";
      authMessage.className = "cp-hint-text cp-hint-success";
    }
    await initConnectionStatus();
    await loadVaultMemories();
    await loadPreferences();
  });
  if (saveBtn) {
    saveBtn.addEventListener("click", async () => {
      const newUrl = urlInput?.value.trim() || DEFAULT_BACKEND_URL;
      const newToken = tokenInput?.value.trim() || "";
      try {
        await ensureBackendPermission(newUrl);
      } catch (error) {
        if (authMessage) {
          authMessage.textContent = error?.message || "Backend permission was not granted.";
          authMessage.className = "cp-hint-text cp-hint-error";
        }
        return;
      }
      await setSetting("backend_url", newUrl);
      await setSetting("auth_token", newToken);
      apiClient.setBackendUrl(newUrl);
      apiClient.setToken(newToken);
      if (!newToken) await setSetting("refresh_token", "");
      await syncAccountView();
      saveBtn.textContent = "Saved!";
      setTimeout(() => saveBtn.textContent = "Save Settings", 1500);
      await initConnectionStatus();
      await loadVaultMemories();
      await loadPreferences();
    });
  }
}
function initVault() {
  const refreshBtn = document.getElementById("vault-refresh-btn");
  if (refreshBtn) {
    refreshBtn.addEventListener("click", () => loadVaultMemories());
  }
  loadVaultMemories();
}
async function loadVaultMemories() {
  const listEl = document.getElementById("vault-list");
  if (!listEl) return;
  const token = await getSetting("auth_token");
  if (!token) {
    listEl.innerHTML = `
      <div class="cp-empty-state" role="status">
        <div class="cp-empty-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
          </svg>
        </div>
        <div class="cp-empty-title">Sign in to view your vault</div>
        <p class="cp-empty-desc">Open the Settings tab to sign in or supply your Supabase auth token.</p>
        <button type="button" class="cp-btn cp-btn-secondary cp-empty-action" id="vault-open-settings-btn">Open Settings</button>
      </div>
    `;
    listEl.querySelector("#vault-open-settings-btn")?.addEventListener("click", () => switchToTab("settings"));
    return;
  }
  listEl.innerHTML = `
    <div class="cp-loading-state" role="status" aria-live="polite">
      <div class="cp-spinner" aria-hidden="true"></div>
      <p class="cp-loading-text">Loading memories...</p>
    </div>
  `;
  try {
    const memories = await apiClient.getAllMemories();
    if (!memories || memories.length === 0) {
      listEl.innerHTML = `
        <div class="cp-empty-state" role="status">
          <div class="cp-empty-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
          </div>
          <div class="cp-empty-title">No memories stored yet</div>
          <p class="cp-empty-desc">Enable capture in Settings and converse on ChatGPT, Claude, or Gemini to automatically distill facts.</p>
        </div>
      `;
      return;
    }
    listEl.innerHTML = "";
    memories.forEach((mem) => listEl.appendChild(renderMemoryCard(mem)));
  } catch (err) {
    const isAuthError = /HTTP 401|HTTP 403|token_expired|Session expired/i.test(err?.message || "");
    const isOffline = /failed to fetch|offline|networkerror|econnrefused/i.test(err?.message || "");
    let title = "Error loading memories";
    let desc = escapeHtml(err?.message || "An unexpected error occurred.");
    let actionLabel = "Retry";
    let actionCallback = () => loadVaultMemories();
    if (isAuthError) {
      title = "Authentication expired";
      desc = "Your session has expired. Please sign in again from the Settings tab.";
      actionLabel = "Go to Settings";
      actionCallback = () => switchToTab("settings");
    } else if (isOffline) {
      title = "Backend server offline";
      desc = "Could not reach the configured backend. Check the backend URL in Settings and verify it is running.";
    }
    listEl.innerHTML = `
      <div class="cp-error-state" role="alert" aria-live="assertive">
        <div class="cp-error-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="12" y1="8" x2="12" y2="12"/>
            <line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
        </div>
        <div class="cp-error-title">${title}</div>
        <div class="cp-error-desc">${desc}</div>
        <div class="cp-error-actions">
          <button type="button" class="cp-btn cp-btn-secondary cp-error-btn" id="vault-error-action-btn">${actionLabel}</button>
        </div>
      </div>
    `;
    listEl.querySelector("#vault-error-action-btn")?.addEventListener("click", actionCallback);
  }
}
function actionButton(label, action, danger = false) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = `cp-card-btn${danger ? " cp-card-btn-danger" : ""}`;
  button.textContent = label;
  button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      await action();
    } catch (error) {
      const status = button.closest(".cp-card")?.querySelector(".cp-card-status");
      if (status) status.textContent = error?.message || "Action failed. Try again.";
    } finally {
      button.disabled = false;
    }
  });
  return button;
}
function editCard(card, initialText, save) {
  const editor = document.createElement("div");
  editor.className = "cp-card-editor";
  const input = document.createElement("textarea");
  input.className = "cp-textarea";
  input.value = initialText;
  input.rows = 3;
  input.setAttribute("aria-label", "Correct wording");
  const actions = document.createElement("div");
  actions.className = "cp-card-actions";
  actions.append(actionButton("Save correction", async () => {
    const value = input.value.trim();
    if (!value) throw new Error("Wording cannot be empty.");
    if (containsSecret(value)) throw new Error("Correction cannot contain credentials or secrets.");
    await save(value);
  }), actionButton("Cancel", async () => {
    editor.remove();
  }));
  editor.append(input, actions);
  card.appendChild(editor);
  input.focus();
}
function cardStatus(card) {
  const status = document.createElement("div");
  status.className = "cp-card-status";
  status.setAttribute("role", "status");
  card.appendChild(status);
  return status;
}
function renderMemoryCard(mem) {
  const card = document.createElement("article");
  card.className = "cp-card";
  card.setAttribute("data-id", mem.id);
  const top = document.createElement("div");
  top.className = "cp-card-top";
  for (const [value, tone] of [[mem.classification || "general", mem.classification === "sensitive" ? "error" : "neutral"], [mem.status || "active", mem.status === "blocked" ? "error" : "success"]]) {
    const badge = document.createElement("span");
    badge.className = `cp-badge cp-badge-${tone}`;
    badge.textContent = value;
    top.appendChild(badge);
  }
  const wording = document.createElement("div");
  wording.className = "cp-card-text";
  wording.textContent = mem.text;
  const evidence = document.createElement("p");
  evidence.className = "cp-evidence";
  evidence.textContent = `Evidence: ${mem.evidence_excerpt || "No excerpt available"}`;
  const meta = document.createElement("div");
  meta.className = "cp-card-meta";
  meta.textContent = `${mem.source || "Unknown source"} \xB7 ${formatDate(mem.created_at) || "Date unavailable"}`;
  const actions = document.createElement("div");
  actions.className = "cp-card-actions";
  actions.appendChild(actionButton("Correct", async () => {
    card.querySelector(".cp-card-editor")?.remove();
    editCard(card, mem.text, async (value) => {
      await apiClient.updateMemory(mem.id, value);
      await loadVaultMemories();
    });
  }));
  if (mem.status !== "blocked") actions.appendChild(actionButton("Block", async () => {
    if (!await apiClient.blockMemory(mem.id)) throw new Error("Could not block memory.");
    await loadVaultMemories();
  }));
  actions.appendChild(actionButton("Forget", async () => {
    if (!window.confirm("Forget this memory and its stored history?")) return;
    if (!await apiClient.deleteMemory(mem.id)) throw new Error("Could not forget memory.");
    await loadVaultMemories();
  }, true));
  card.append(top, wording, evidence, meta, actions);
  cardStatus(card);
  return card;
}
function initPreferences() {
  const refreshBtn = document.getElementById("pref-refresh-btn");
  if (refreshBtn) {
    refreshBtn.addEventListener("click", () => loadPreferences());
  }
  loadPreferences();
}
async function loadPreferences() {
  const listEl = document.getElementById("preferences-list");
  if (!listEl) return;
  const token = await getSetting("auth_token");
  if (!token) {
    listEl.innerHTML = `
      <div class="cp-empty-state" role="status">
        <div class="cp-empty-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
          </svg>
        </div>
        <div class="cp-empty-title">Sign in to view preferences</div>
        <p class="cp-empty-desc">Open the Settings tab to sign in or supply your Supabase auth token.</p>
        <button type="button" class="cp-btn cp-btn-secondary cp-empty-action" id="pref-open-settings-btn">Open Settings</button>
      </div>
    `;
    listEl.querySelector("#pref-open-settings-btn")?.addEventListener("click", () => switchToTab("settings"));
    return;
  }
  listEl.innerHTML = `
    <div class="cp-loading-state" role="status" aria-live="polite">
      <div class="cp-spinner" aria-hidden="true"></div>
      <p class="cp-loading-text">Loading preferences...</p>
    </div>
  `;
  try {
    const preferences = await apiClient.getPreferences();
    if (!preferences || preferences.length === 0) {
      listEl.innerHTML = `
        <div class="cp-empty-state" role="status">
          <div class="cp-empty-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
            </svg>
          </div>
          <div class="cp-empty-title">No preferences promoted yet</div>
          <p class="cp-empty-desc">Context Passport learns how you like explanations after 3 distinct observations across at least 2 separate chats.</p>
        </div>
      `;
      return;
    }
    listEl.innerHTML = "";
    preferences.forEach((pref) => listEl.appendChild(renderPreferenceCard(pref)));
  } catch (err) {
    const isAuthError = /HTTP 401|HTTP 403|token_expired|Session expired/i.test(err?.message || "");
    const isOffline = /failed to fetch|offline|networkerror|econnrefused/i.test(err?.message || "");
    let title = "Error loading preferences";
    let desc = escapeHtml(err?.message || "An unexpected error occurred.");
    let actionLabel = "Retry";
    let actionCallback = () => loadPreferences();
    if (isAuthError) {
      title = "Authentication expired";
      desc = "Your session has expired. Please sign in again from the Settings tab.";
      actionLabel = "Go to Settings";
      actionCallback = () => switchToTab("settings");
    } else if (isOffline) {
      title = "Backend server offline";
      desc = "Could not reach the configured backend. Check the backend URL in Settings and verify it is running.";
    }
    listEl.innerHTML = `
      <div class="cp-error-state" role="alert" aria-live="assertive">
        <div class="cp-error-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="12" y1="8" x2="12" y2="12"/>
            <line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
        </div>
        <div class="cp-error-title">${title}</div>
        <div class="cp-error-desc">${desc}</div>
        <div class="cp-error-actions">
          <button type="button" class="cp-btn cp-btn-secondary cp-error-btn" id="pref-error-action-btn">${actionLabel}</button>
        </div>
      </div>
    `;
    listEl.querySelector("#pref-error-action-btn")?.addEventListener("click", actionCallback);
  }
}
function renderPreferenceCard(pref) {
  const card = document.createElement("article");
  card.className = "cp-card";
  card.setAttribute("data-id", pref.id);
  const top = document.createElement("div");
  top.className = "cp-card-top";
  const classBadge = document.createElement("span");
  classBadge.className = "cp-badge cp-badge-neutral";
  classBadge.textContent = "general";
  const state = document.createElement("span");
  let statusTone = "neutral";
  if (pref.status === "active") statusTone = "success";
  else if (pref.status === "blocked") statusTone = "error";
  else if (pref.status === "insufficient_evidence") statusTone = "warning";
  state.className = `cp-badge cp-badge-${statusTone}`;
  state.textContent = pref.status || "active";
  const evidenceCount = document.createElement("span");
  evidenceCount.className = "cp-badge cp-badge-neutral";
  evidenceCount.textContent = pref.locked ? "Your wording \xB7 locked" : `${pref.evidence_count || 0} observations`;
  top.append(classBadge, state, evidenceCount);
  const wording = document.createElement("div");
  wording.className = "cp-card-text";
  wording.textContent = pref.preference_text;
  const meta = document.createElement("div");
  meta.className = "cp-card-meta";
  meta.textContent = `${pref.preference_key.replaceAll("_", " ")} \xB7 ${pref.conversation_count || 0} chats`;
  const evidence = document.createElement("div");
  evidence.className = "cp-evidence-list";
  for (const observation of pref.supporting_observations || []) {
    const row = document.createElement("div");
    row.className = "cp-evidence-row";
    const excerpt = document.createElement("span");
    excerpt.textContent = observation.excerpt || "[Evidence redacted]";
    row.append(excerpt, actionButton("Remove", async () => {
      if (!await apiClient.removePreferenceEvidence(pref.id, observation.id)) throw new Error("Could not remove evidence.");
      await loadPreferences();
    }));
    evidence.appendChild(row);
  }
  const actions = document.createElement("div");
  actions.className = "cp-card-actions";
  actions.appendChild(actionButton("Correct", async () => {
    card.querySelector(".cp-card-editor")?.remove();
    editCard(card, pref.preference_text, async (value) => {
      await apiClient.updatePreference(pref.id, value);
      await loadPreferences();
    });
  }));
  if (pref.status !== "blocked") actions.appendChild(actionButton("Block", async () => {
    if (!await apiClient.blockPreference(pref.id)) throw new Error("Could not block preference.");
    await loadPreferences();
  }));
  actions.appendChild(actionButton("Forget", async () => {
    if (!window.confirm("Forget this preference and remove its supporting evidence?")) return;
    if (!await apiClient.forgetPreference(pref.id)) throw new Error("Could not forget preference.");
    await loadPreferences();
  }, true));
  card.append(top, wording, meta, evidence, actions);
  cardStatus(card);
  return card;
}
function initFallback() {
  const draftInput = document.getElementById("fallback-input");
  const retrieveBtn = document.getElementById("fallback-retrieve-btn");
  const sensitivePanel = document.getElementById("fallback-sensitive-panel");
  const sensitiveText = document.getElementById("fallback-sensitive-text");
  const allowSensitiveCb = document.getElementById("fallback-allow-sensitive");
  const outputText = document.getElementById("fallback-output");
  const copyBtn = document.getElementById("fallback-copy-btn");
  let lastGeneralMemories = [];
  let lastSensitiveMemories = [];
  let lastPreferences = [];
  const updatePreparedOutput = () => {
    if (!outputText || !draftInput) return;
    const includeSensitive = allowSensitiveCb ? allowSensitiveCb.checked : false;
    const approvedSensitive = includeSensitive ? lastSensitiveMemories : [];
    const block = formatMemoryBlock(lastGeneralMemories, approvedSensitive, lastPreferences);
    const prepared = applyMemoryBlockToDraft(draftInput.value, block);
    outputText.value = prepared;
  };
  if (retrieveBtn) {
    retrieveBtn.addEventListener("click", async () => {
      const query = draftInput?.value.trim() || "General user preferences";
      if (containsSecret(query)) {
        if (outputText) outputText.value = "";
        if (sensitivePanel) sensitivePanel.style.display = "none";
        alert("Recognizable secret in draft. Memory recall cancelled for privacy.");
        return;
      }
      retrieveBtn.textContent = "Retrieving...";
      try {
        const res = await apiClient.queryMemories(query, 3);
        if (draftInput?.value.trim() !== query) {
          retrieveBtn.textContent = "Draft changed\u2014retrieve again";
          return;
        }
        const screened = screenRecall(res);
        lastGeneralMemories = screened.general;
        lastSensitiveMemories = screened.sensitive;
        lastPreferences = screened.preferences;
        if (lastSensitiveMemories.length > 0 && sensitivePanel && sensitiveText) {
          sensitivePanel.style.display = "block";
          sensitiveText.textContent = lastSensitiveMemories.map((m) => m.text).join("; ");
          if (allowSensitiveCb) allowSensitiveCb.checked = false;
        } else if (sensitivePanel) {
          sensitivePanel.style.display = "none";
        }
        updatePreparedOutput();
        retrieveBtn.textContent = "Memories Retrieved!";
        setTimeout(() => retrieveBtn.textContent = "Retrieve Relevant Memories", 2e3);
      } catch (err) {
        alert(`Error querying memories: ${err.message}`);
        retrieveBtn.textContent = "Retrieve Relevant Memories";
      }
    });
  }
  draftInput?.addEventListener("input", () => {
    lastGeneralMemories = [];
    lastSensitiveMemories = [];
    lastPreferences = [];
    if (allowSensitiveCb) allowSensitiveCb.checked = false;
    if (sensitivePanel) sensitivePanel.style.display = "none";
    if (outputText) outputText.value = draftInput.value;
  });
  if (allowSensitiveCb) {
    allowSensitiveCb.addEventListener("change", () => {
      updatePreparedOutput();
    });
  }
  if (copyBtn) {
    copyBtn.addEventListener("click", async () => {
      if (!outputText || !outputText.value.trim()) return;
      await navigator.clipboard.writeText(outputText.value);
      copyBtn.textContent = "Copied to Clipboard!";
      setTimeout(() => copyBtn.textContent = "Copy Prepared Prompt", 2e3);
    });
  }
}
function escapeHtml(str) {
  if (!str) return "";
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
function formatDate(iso) {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    return d.toLocaleDateString(void 0, { month: "short", day: "numeric" });
  } catch {
    return "";
  }
}
//# sourceMappingURL=sidepanel.js.map
